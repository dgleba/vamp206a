
<?php require 'templates/head.php';?>
<?php require 'nav.php';?>


<?php require 'indexbody.php';?>
<?php //require 'templates/spacer.php';?>

<?php require 'templates/foot.php';?>

