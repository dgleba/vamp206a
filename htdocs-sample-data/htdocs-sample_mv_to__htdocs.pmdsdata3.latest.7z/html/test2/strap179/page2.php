
<?php require 'templates/head.php';?>
<?php require 'nav.php';?>


<?php require 'page2body.php';?>

<?php //require 'templates/spacer.php';?>


<?php require 'templates/foot.php';?>

