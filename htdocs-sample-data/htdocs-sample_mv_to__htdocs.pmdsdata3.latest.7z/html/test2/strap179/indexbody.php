    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Testing.. Starter Template</h1>
            </div>
        </div>
        <!-- /.row -->
        
        <div class="container theme-showcase" class="page-section" style="padding-bottom:30px">
				
					<h2 id ="apps" class="page-header">Applications</h2>
					<!-- <a href="#"><p><small>Back to Top</small><br><br></p></a> -->
					
					<div class="col-sm-6" class="list-group">
						
						<a href="/leanmfg/" target="_blank"  class="list-group-item list-group-item-success"><b>SWI Numbers</b></a>
						<a href="/prodrpt/" target="_blank"  class="list-group-item"><b>Prodigy - (Production Status App)</b></a>
						<a href="/shiftcsd1/" target="_blank"  class="list-group-item list-group-item-success"><b>CSD1 Shift Reports</b></a>
						<a href="/shiftcsd1sup/" target="_blank"  class="list-group-item"><b>CSD1 Supervisor Shift Reports</b></a>
						<a href="/shiftsmsmeer/" target="_blank"  class="list-group-item list-group-item-success"><b>SMS Meer Press Shift Report</b></a>
						<a href="/shiftcsd2/" target="_blank"  class="list-group-item"><b>CSD2 Shift Reports</b></a>
						<a href="/shiftcsd2sup/" target="_blank"  class="list-group-item list-group-item-success"><b>CSD2 Supervisor Shift Reports</b></a>
						<a href="" target="_blank"  class="list-group-item "><b> </b></a>
						<a href="/index1orig.html" target="_blank"  class="list-group-item list-group-item-warning"><b>...The Original Menu... plus very long extra text to see what that looks like.</b></a>
						
					</div>
					
				</div> 
       
    </div>
    <!-- /.container -->
    
