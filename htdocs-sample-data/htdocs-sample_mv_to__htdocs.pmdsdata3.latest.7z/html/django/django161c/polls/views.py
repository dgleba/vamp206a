from django.shortcuts import render
from django.http import HttpResponse
#from django.http import datetime
# Create your views here.

def start(request):
   #now = datetime.datetime.now()
   html="<html><body>It is now %s.</body></html>"
   html="<html><body><h2>Coming Soon!</h2>The Database flexibility you've always wanted.  03:11PM %s</body></html>"

   return HttpResponse(html)